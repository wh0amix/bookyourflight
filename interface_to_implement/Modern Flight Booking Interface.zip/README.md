
  # Modern Flight Booking Interface

  This is a code bundle for Modern Flight Booking Interface. The original project is available at https://www.figma.com/design/bss8huSSRngdIJMS4K0yjU/Modern-Flight-Booking-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  